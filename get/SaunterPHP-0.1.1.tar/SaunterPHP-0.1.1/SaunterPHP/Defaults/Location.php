<?php

class SaunterPHP_Defaults_Location {
    function getDefaultsLocation() {
         return dirname(__FILE__);
     }
}

?>