#!/usr/bin/env php

<?php

require_once 'PEAR/Info.php';

function initialize() {
    $options = array('resume' =>  PEAR_INFO_PACKAGES,
                     'channels' => array('pear.phpunit.de')
    );
    
    $info = new PEAR_Info("", "", "", $options);
    $info->display();
    
    
    # conf
    // if (! is_dir("conf")) {
    //     mkdir("conf");
    // }
    // copy(, "conf/settings.inc.default");
    
}

if (in_array("--new", $argv)) {
    initialize();
}

?>