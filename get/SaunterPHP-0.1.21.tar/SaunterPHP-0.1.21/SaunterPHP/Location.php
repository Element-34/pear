<?php
/**
 * @package SaunterPHP
 */
 
class SaunterPHP_Location {
    function getLocation() {
         return dirname(__FILE__);
     }
}

?>